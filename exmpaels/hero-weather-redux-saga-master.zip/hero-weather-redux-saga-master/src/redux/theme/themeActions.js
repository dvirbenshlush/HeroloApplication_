import { THEME_TOGGLE } from './themeConstants'

export const darkModeToggle = () => ({
  type: THEME_TOGGLE,
})
