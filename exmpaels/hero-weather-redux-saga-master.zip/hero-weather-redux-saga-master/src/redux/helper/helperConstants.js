export const CITY_BY_NAME_URL =
  'https://dataservice.accuweather.com/locations/v1/cities/search?apikey='

export const CITY_BY_COORDS_URL =
  'https://dataservice.accuweather.com/locations/v1/cities/geoposition/search?apikey='
